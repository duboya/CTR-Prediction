[TOC]

# Formula

## Line

$$ f = \frac{a}{b} $$

## Inline

$ \vec{a} $ and $ \vec{b} $

# Center Tag

## Text

<center> What doesn't kill you makes you stronger. </center>

## Picture

<center> ![](1.jpg) </center>